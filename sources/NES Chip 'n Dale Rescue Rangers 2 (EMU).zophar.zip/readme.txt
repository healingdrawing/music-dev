zopharNumber comment - zopharTrackName

10 adventureSea - Stage 3: Harbor
20 adventureBrave - Stage 6c: Future World
22 dangerFeel - Stage 7: The Secret Passage
31 training - Unknown Track
